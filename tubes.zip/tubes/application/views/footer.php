
<footer style="background-color: #000000; color: white"  > <br> <br>

 
  <div style="height: 100px" class="footer-copyright text-center py-3">© 2018 Copyright: TRIPLEX <br>

  </div>


</footer>
