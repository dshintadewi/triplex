<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="41892672170-gm32ith8jnep67vj3r4a30m9taliri8q.apps.googleusercontent.com";
$config['google_client_secret']="CgsvzNmMI_kVVoWw69yRXokz";
$config['google_redirect_url']=base_url().'index.php/welcome/form_lapor';

